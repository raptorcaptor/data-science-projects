#!/usr/bin/env python
# coding: utf-8

# In[637]:


#
# Author: Chileen Duncan
# Purpose: IST 718 Lab 3
# Code from:
# Course Github
# https://betiq.teamrankings.com/college-football/betting-trends/win-loss-records/ (win/loss 2021)
# https://betiq.teamrankings.com/college-football/betting-trends/win-loss-records/?season=2018 (win/loss 2018)
# https://www.coacheshotseat.com/CFBCoachesSalaries.htm (Coach Salaries 2021)
# https://www.geeksforgeeks.org/how-to-make-a-table-in-python/
#


# In[638]:


# import packages for analysis and modeling
import pandas as pd #data frame operations
import numpy as np #arrays and math functions
from sklearn.metrics import mean_squared_error # test model
from sklearn.linear_model import LinearRegression
from math import sqrt
from scipy.stats import uniform #for training and test splits
import statsmodels.api as sm #R-like model specification
import statsmodels.formula.api as smf  # R-like model specification
import matplotlib.pyplot as plt #2D plotting
# pip install tabulate to make a cool table
from tabulate import tabulate

import seaborn as sns  # PROVIDES TRELLIS AND SMALL MULTIPLE PLOTTING


# In[639]:


############################
# Obtain Data              #
############################

# read in supplied Coaches data and create data frame
    
Coaches2018 = pd.read_csv("coaches9.csv")

print(Coaches2018.head())

print(Coaches2018.describe())
Coaches2018.shape


# In[640]:


# read in newly acquired Coaches data from 2022 and add to exisiting data frame
    
Coaches2021 = pd.read_csv("CoachesSalaries2021.csv")

print(Coaches2021.head())

print(Coaches2021.describe())
Coaches2021.shape


# In[641]:


# read in newly acquired Win-loss data from 2021 and add to exisiting data frame
    
WinLoss2021 = pd.read_csv("CollegeFBWinLoss2021.csv")

print(WinLoss2021.head())

print(WinLoss2021.describe())
WinLoss2021.shape


# In[642]:


# read in newly acquired Win-loss data from 2018 and add to exisiting data frame
    
WinLoss2018 = pd.read_csv("CollegeFBWinLoss2018.csv")

print(WinLoss2018.head())

print(WinLoss2018.describe())
WinLoss2018.shape


# In[643]:


# Merge coach data into one df under temp file for error checking

temp1 = pd.merge(Coaches2018, Coaches2021, how="outer", on=["School"])
print(temp1.head())
temp1.describe()


# In[644]:


# Merge Win/Loss data into one df under temp file for error checking

temp2 = pd.merge(WinLoss2018, WinLoss2021, how="outer", on=["School"])
print(temp2.head(20))
temp2.describe()


# In[645]:


# Merge all data into one df under temp file for error checking

temp3 = pd.merge(temp1, temp2, how="outer", on=["School"])
print(temp3.head())
temp3.describe()


# In[646]:


############################
# Scrub Data               #
############################

# Drop unnecessary columns not needed in this analysis

temp3 = temp3.drop(['Bonus', 'Buyout', 'Buyout_2021', 'AssistantPay', 'BonusPaid', 'Conference_2021'], axis = 1) 
# making assumption off of preliminary exploration that conference does not change, at least not enough to impact this analysis


# In[647]:


FullCFS = pd.DataFrame(temp3) # make sure it's a dataframe, change to a less bad name
print(FullCFS.head())
FullCFS.shape # check that no data was lost


# In[648]:


# pretty print the dataframe to help identify dirty data
# snippet from https://www.stackvidhya.com/pretty-print-dataframe/

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)
pd.set_option('display.colheader_justify', 'center')
pd.set_option('display.precision', 3)

display(FullCFS)


# In[649]:


# Replace "--" with "NA"

tmp = FullCFS.replace("--", "0")
tmp1 = tmp.replace("—", "0")
tmp1.shape


# In[650]:


# Try dropping where more than 2 NAs
# tmp3 = tmp2.dropna(thresh = 2) hates itself and isn't working
# Decided to drop all NAs as valuable information has also been added to round out the dataset

tmp2 = tmp1.dropna() # not dropping all NAs, clean up manually, investigate further
tmp2.head(130)
# tmp2.shape # (129, 16)
tmp2 = tmp2[tmp2["SchoolPay_2021"] != "0"]
tmp2 = tmp2[tmp2["SchoolPay"] != "0"]
# print(tmp2.shape) # (121, 16)
tmp2.head(130)


# In[651]:


# pretty print the dataframe to verify cleaning
# snippet from https://www.stackvidhya.com/pretty-print-dataframe/

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', 1000)
pd.set_option('display.colheader_justify', 'center')
pd.set_option('display.precision', 3)

# rename temporary variable

FullCFS = tmp2
display(FullCFS)


# In[652]:


# Create dataframe #1 For training later

DF2018 = FullCFS[["School", "Conference","Coach", "SchoolPay", "TotalPay", "Win-Loss_2018", "Win%_2018", "Mov_2018", "ATS_2018"]]
# rename columns
DF2018.columns = ["School", "Conference","Coach", "SchoolPay", "TotalPay", "Win-Loss", "WinPerc", "Mov", "ATS"]
DF2018.head()


# In[653]:


# Convert to numeric

DF2018['TotalPay'] = pd.to_numeric(DF2018['TotalPay'])
DF2018['WinPerc'] = pd.to_numeric(DF2018['WinPerc'])
DF2018.info()


# In[654]:


# Create dataframe #2 For testing later

DF2021 = FullCFS[["School", "Conference","Coach_2021", "SchoolPay_2021", "TotalPay_2021", "Win-Loss_2021", "Win%_2021", "Mov_2021", "ATS_2021"]]
# rename columns
DF2021.columns = ["School", "Conference","Coach", "SchoolPay", "TotalPay", "Win-Loss", "WinPerc", "Mov", "ATS"]
DF2021.head()


# In[655]:


# Convert to numeric

DF2021['TotalPay'] = pd.to_numeric(DF2021['TotalPay'])
DF2021['WinPerc'] = pd.to_numeric(DF2021['WinPerc'])
DF2021.info()


# In[656]:


############################
# Explore Data             #
############################

print("The average Coach salary is:", np.mean(DF2018["TotalPay"])) # format better
print("The minimum Coach Salary is:", np.min(DF2018["TotalPay"]))
print("The maximum Coach Salary is:", np.max(DF2018["TotalPay"]))

# Histogram of 2018 Total Pay
plt.hist(DF2018['TotalPay'], stacked = False, rwidth = .8, color='forestgreen')
plt.title("Salary Distribution for 2018")

plt.show()


# In[657]:


# boxplot #1 (adapted from course code)

fig, axis = plt.subplots()
axis.set_ylabel('Salary')
sal_plot = plt.boxplot(DF2018['TotalPay'], sym='o', vert=1, whis=1.5)
plt.setp(sal_plot['boxes'], color = 'green')    
plt.setp(sal_plot['whiskers'], color = 'green')    
plt.setp(sal_plot['fliers'], color = 'green', marker = 'o')
print("Salary Distribution")
plt.show()


# In[658]:


# fix names for conversion
MAC = DF2018[DF2018['Conference'] == 'MAC']
SEC = DF2018[DF2018['Conference'] == 'SEC']
CUSA = DF2018[DF2018['Conference'] == 'C-USA']
SunBelt = DF2018[DF2018['Conference'] == 'Sun Belt']
Pac12 = DF2018[DF2018['Conference'] == 'Pac-12']
MtWest = DF2018[DF2018['Conference'] == 'Mt. West']
AAC = DF2018[DF2018['Conference'] == 'AAC']
ACC = DF2018[DF2018['Conference'] == 'ACC']
BigTen = DF2018[DF2018['Conference'] == 'Big Ten']
Ind = DF2018[DF2018['Conference'] == 'Ind.']

# convert conference salary into list of vectors for box plot
data = [MAC['TotalPay'], SEC['TotalPay'], 
    CUSA['TotalPay'], SunBelt['TotalPay'], 
    Pac12['TotalPay'], MtWest['TotalPay'], 
    AAC['TotalPay'], ACC['TotalPay'], BigTen['TotalPay'], Ind['TotalPay']]
ConfNames = ['MAC', 'SEC', 'CUSA', 'SunBelt', 'Pac12', 'MtWest', 'AAC', 'ACC', 'BigTen', 'Ind']


# In[659]:


# boxplot #2 (adapted from course code)

fig, axis = plt.subplots()
axis.set_ylabel('Salary')
axis.set_xlabel('Conferences')
sal_plot = plt.boxplot(data, sym='o', vert=1, whis=1.5)
plt.setp(sal_plot['boxes'], color = 'green')    
plt.setp(sal_plot['whiskers'], color = 'green')    
plt.setp(sal_plot['fliers'], color = 'green', marker = 'o')
axis.set_xticklabels(ConfNames)
plt.xticks(rotation=45)
print("Salary distribution across conferences")
plt.show()


# In[660]:


# scatterplot #1 (adapted from course code)
# figure out how to visualize better

sns.stripplot(x="Mov", y="TotalPay", 
              data=DF2018, size = 4)
plt.xticks(rotation=45)
print("Salary distribution across margin of victory")
plt.show()


# In[661]:


# scatterplot #2
# check correlation with WinPerc

sns.stripplot(x="Conference", y="TotalPay", 
              data=DF2018, size = 4)
plt.xticks(rotation=45)
print("Salary distribution across conferences")
plt.show()


# In[662]:


# QUICK SCATTER PLOT TO LOOK AT RELATIONSHIP BETWEEN VARIABLES

sns.set(color_codes=True)

sns.regplot(x="WinPerc", y="TotalPay", data=DF2018, y_jitter=0.03, color = 'green')
print("Percentage of time the team won")
plt.show()


# In[663]:


sns.regplot(x="Mov", y="TotalPay", data=DF2018, y_jitter=0.03, color = 'green')
print("Average margin of victory")
plt.show()


# In[664]:


sns.regplot(x="ATS", y="TotalPay", data=DF2018, y_jitter=0.03, color = 'green')
print("Average amount of points the team covers the spread by")
plt.show()


# In[665]:


sns.pairplot(data=DF2018)
plt.show()


# In[666]:


# check correlation
# adapted from course code

corr = DF2018.corr()
# Generate a mask for the upper triangle
mask = np.zeros_like(corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set up the matplotlib figure
#f, ax = plt.subplots(figsize=(11, 9))

# Generate a custom diverging colormap
cmap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})
plt.show()


# In[671]:


############################
# Model Data               #
############################

############################
# Model #1 Linear Regression - The Bestest(so far)
############################

# adapted from course code
# employ training-and-test regimen for model validation
np.random.seed(1234)

train = DF2018
test = DF2021
# check training data frame
print('\DF2018, the train data frame (rows, columns): ',train.shape)
print(train.head())
# check test data frame
print('\DF2021, the test data frame (rows, columns): ',test.shape)
print(test.head())


# In[672]:


# specify a simple model

my_model = str('TotalPay ~ Conference + Mov')

# fit the model to the training set
train_model_fit = smf.ols(my_model, data = train).fit()

# summary of model fit to the training set
print(train_model_fit.summary())


# In[673]:


# training set predictions from the model fit to the training set
train['predict_TotalPay'] = train_model_fit.fittedvalues

# test set predictions from the model fit to the training set
test['predict_TotalPay'] = train_model_fit.predict(test)


# In[674]:


sns.boxplot(x = "Conference", y="TotalPay", data=train, color = "lightgreen")
plt.xticks(rotation=45)
print("Actual Salary v. Predicted Salary")
plt.show()

sns.boxplot(x = "Conference", y="predict_TotalPay", data=train, color = "pink")
plt.xticks(rotation=45)
plt.show()


# In[675]:


# Calculate root mean square error

result = sqrt(mean_squared_error(train['TotalPay'], train['predict_TotalPay']))
print("The RSME for the Conference and Mov variables is:", result)


# In[676]:


# normalize RSME
# RSME/(max TotalPay - min TotalPay)

a = np.max(DF2018["TotalPay"])
b = np.min(DF2018["TotalPay"])

normRSME = result/(a-b)
print("The normalized RSME for the Conference and Mov variables is:", normRSME)


# In[677]:


# produce resididual plots for Mov variable

fig = plt.figure(figsize=(12,8))

fig = sm.graphics.plot_regress_exog(train_model_fit, 'Mov', fig=fig)


# In[678]:


############################
# Model #1-1
############################

# specify a simple model
my_model = str('TotalPay ~ Conference + WinPerc')

# fit the model to the training set
train_model_fit = smf.ols(my_model, data = train).fit()

# summary of model fit to the training set
print(train_model_fit.summary())


# In[679]:


# produce resdidual plots for WinPerc variable

fig = plt.figure(figsize=(12,8))

fig = sm.graphics.plot_regress_exog(train_model_fit, 'WinPerc', fig=fig)


# In[680]:


############################
# Model #1-2
############################

# specify a simple model
my_model = str('TotalPay ~ Conference')

# fit the model to the training set
train_model_fit = smf.ols(my_model, data = train).fit()

# summary of model fit to the training set
print(train_model_fit.summary())


# In[681]:


############################
# Model #1-3
############################

# specify a simple model
my_model = str('TotalPay ~ WinPerc') # Mov is R2: 0.08

# fit the model to the training set
train_model_fit = smf.ols(my_model, data = train).fit()

# summary of model fit to the training set
print(train_model_fit.summary())


# In[682]:


# check correlation again #
# adapted from course code

corr = DF2018.corr()
# Generate a mask for the upper triangle
mask = np.zeros_like(corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set up the matplotlib figure
#f, ax = plt.subplots(figsize=(11, 9))

# Generate a custom diverging colormap
cmap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
print("2018")
sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})
plt.show()


# In[683]:


############################
# Model #2 - Compare using different years v. splitting the dataset
############################

# adapted from course code
# employ training-and-test regimen for model validation
np.random.seed(1234)

DF2018['runiform'] = uniform.rvs(loc = 0, scale = 1, size = len(DF2018))
DF2018_train = DF2018[DF2018['runiform'] >= 0.33]
DF2018_test = DF2018[DF2018['runiform'] < 0.33]
# check training data frame
print('\nDF2018_train data frame (rows, columns): ',DF2018_train.shape)
print(DF2018_train.head())
# check test data frame
print('\nDF2018_test data frame (rows, columns): ',DF2018_test.shape)
print(DF2018_test.head())


# In[684]:


# specify a simple model

my_model1 = str('TotalPay ~ Conference + Mov')

# fit the model to the training set
train_model_fit1 = smf.ols(my_model1, data = DF2018_train).fit()

# summary of model fit to the training set
print(train_model_fit1.summary())


# In[685]:


# training set predictions from the model fit to the training set
DF2018_train['predict_TotalPay'] = train_model_fit1.fittedvalues

# test set predictions from the model fit to the training set
DF2018_test['predict_TotalPay'] = train_model_fit1.predict(DF2018_test)


# In[686]:


sns.boxplot(x = "Conference", y="TotalPay", data=DF2018_train, color = "lightgreen")
plt.xticks(rotation=45)
plt.show()

sns.boxplot(x = "Conference", y="predict_TotalPay", data=DF2018_test, color = "pink")
plt.xticks(rotation=45)
plt.show()


# In[687]:


# Calculate root mean square error

result1 = sqrt(mean_squared_error(DF2018_train['TotalPay'], DF2018_train['predict_TotalPay']))
print("The RSME for the Conference and Mov variables is:", result1)


# In[688]:


# normalize RSME
# RSME/(max TotalPay - min TotalPay)

a = np.max(DF2018["TotalPay"])
b = np.min(DF2018["TotalPay"])

normRSME = result1/(a-b)
print("The normalized RSME for the Conference and Mov variables is:", normRSME)


# In[689]:


# produce resididual plots for Mov variable

fig = plt.figure(figsize=(12,8))

fig = sm.graphics.plot_regress_exog(train_model_fit1, 'Mov', fig=fig)


# In[690]:


############################
# Model #2-1
############################

# specify a simple model

my_model1 = str('TotalPay ~ Conference + WinPerc')

# fit the model to the training set
train_model_fit1 = smf.ols(my_model1, data = DF2018_train).fit()

# summary of model fit to the training set
print(train_model_fit1.summary())


# In[691]:


# check correlation again
# adapted from course code

corr = DF2018.corr()
# Generate a mask for the upper triangle
mask = np.zeros_like(corr, dtype=np.bool)
mask[np.triu_indices_from(mask)] = True

# Set up the matplotlib figure
#f, ax = plt.subplots(figsize=(11, 9))

# Generate a custom diverging colormap
cmap = sns.diverging_palette(220, 10, as_cmap=True)

# Draw the heatmap with the mask and correct aspect ratio
print("2018")
sns.heatmap(corr, mask=mask, cmap=cmap, vmax=.3, center=0,
            square=True, linewidths=.5, cbar_kws={"shrink": .5})
plt.show()


# In[692]:


############################
# Interpret Data           #
############################

# https://www.geeksforgeeks.org/how-to-make-a-table-in-python/
 
# assign data
mydata = [
    ["ACC", "$2,920,158", "$3,261,030", "$3,601,902"],
    ["Big Ten", "$3,727,159", "$4,179,030", "$4,630,902"],
    ["AAC(Big East)", "$1,358,159", "$1,699,030", "$2,039,902"],
]
 
# create header
head = ["Conference", "Low End of Salary Range", "Mid Range Salary", "High End of Salary Range"]
 
# display table
print(tabulate(mydata, headers=head, tablefmt="grid"))


# In[ ]:




