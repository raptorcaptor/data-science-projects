#!/usr/bin/env python
# coding: utf-8

# In[ ]:


'''
This program will analyze two datasets from Kaggle.com. 
The first dataset has four parts, and will give us information about individual
movies and metrics. The second dataset will give us information about movie reviews. 
Analyzing both datasets together will give us a more complete picture of the relationship of movie
success to individual movie reviews.
'''

#Author: Chileen Duncan
#Date Sep 2, 2021


# In[ ]:


#######################
#Import packages
#######################

import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

import nltk
import re
import string
import unicodedata
from nltk.corpus import stopwords
#nltk.download()
nltk.download('vader_lexicon')
from nltk.sentiment.vader import SentimentIntensityAnalyzer

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import LabelBinarizer

from nltk.stem.porter import PorterStemmer
from nltk.stem import WordNetLemmatizer
#from wordcloud import WordCloud,STOPWORDS
from nltk.tokenize import word_tokenize,sent_tokenize
from nltk.tokenize.toktok import ToktokTokenizer
from nltk.stem import LancasterStemmer,WordNetLemmatizer

from sklearn.linear_model import LogisticRegression,SGDClassifier
from sklearn.naive_bayes import MultinomialNB
from sklearn.svm import SVC
from sklearn.linear_model import LinearRegression
from textblob import TextBlob
from textblob import Word
from sklearn.metrics import classification_report,confusion_matrix,accuracy_score
from bs4 import BeautifulSoup


# In[4]:


#######################
#Read in files
#######################

title = pd.read_csv("IMDb title_principals.csv") #https://www.kaggle.com/stefanoleone992/imdb-extensive-dataset

names = pd.read_csv("IMDb names.csv") #2

movies = pd.read_csv("IMDb movies.csv") #3

ratings = pd.read_csv("IMDb ratings.csv") #4

movie = pd.read_csv('IMDB Dataset.csv') #https://www.kaggle.com/lakshmi25npathi/imdb-dataset-of-50k-movie-reviews


# In[5]:


#######################
#Set up Dataframe
#######################

title.head() #check structure
title.info() #check number of columns

ratings.head() #check structure
ratings.info() #check number of columns

#Join files on all data

output1 = pd.merge(title,ratings, 
                   on='imdb_title_id', 
                   how='inner')

output1.head() #check structure
output1.info() #check number of columns

movies.head() #check structure
movies.info() #check number of columns

output2 = pd.merge(output1,movies,
                  on = "imdb_title_id",
                  how="inner")

output2.head() #check structure
output2.info() #check number of columns

output2.columns

#Create dataframe with only desired columns
df = pd.DataFrame(output2 , columns = ['imdb_title_id', 'original_title', 'year', 'genre',
       'duration', 'country', 'language','budget', 'worlwide_gross_income','weighted_average_vote','total_votes', 'females_allages_avg_vote', 'males_allages_avg_vote','metascore'])

df.head()

#works!


# In[6]:


#######################
#Data Cleaning
#######################

#Drop duplicates

#df.drop_duplicates("imdb_title_id", keep="last") 

#does not work, investigate

df.head()

df.duplicated().sum() #code sourced online to deal with duplicates, original way would not work
(~df.duplicated()).sum()
df.loc[df.duplicated(), :]
df.drop_duplicates(inplace = True)

df.head() #this drops correctly


#works!

#Drop NA values
#df.dropna() 
#df.head() 

#doesn't work

df.head(10) 

df.info()

len(df) #85846

#Change data types to prepare for descriptive statistics

votesPerYr1 = df.sort_values(by=['weighted_average_vote','year'], ascending=False) #sort top voted movies 

#works!

votesPerYr1.head(50)
#len(votesPerYr1) #85846

votesPerYr1=votesPerYr1.dropna(axis=0, how='any', thresh=None, subset=None, inplace=False) #drop all NA values 

#works!

#len(votesPerYr1) #7093
votesPerYr1.head(10)

votesPerYr1.dtypes


#works!

#Drop non-US movies
votesPerYr1.country=='USA' #find only USA movies

votesPerYr1[votesPerYr1.country=='USA'].shape #removes everything not USA


votesPerYr1.query('country=="USA"').shape

dfnew=votesPerYr1[votesPerYr1.country=='USA']
dfnew1=votesPerYr1.query('country=="USA"')
dfnew.equals(dfnew1) 

dfnew1.head()
votesPerYr = dfnew1

votesPerYr.head()


votesPerYr['total_votes'] = votesPerYr['total_votes'].astype(int) #change type to integer if not already
votesPerYr.dtypes

votesPerYr['metascore'] = votesPerYr['metascore'].astype(int) #change type to integer if not already
votesPerYr.dtypes

votesPerYr['duration'] = votesPerYr['duration'].astype(int) #change type to integer if not already

votesPerYr.head()

#works!

votesPerYr.dtypes

len(votesPerYr) #3677 movies still, good!

#change gross income to int to analyze
votesPerYr['worlwide_gross_income'] = votesPerYr['worlwide_gross_income'].str.replace('$', '').str.replace(',','')
votesPerYr['worlwide_gross_income'] = pd.to_numeric(votesPerYr['worlwide_gross_income'])
votesPerYr['worlwide_gross_income']

#works

#change budget to int to analyze

#votesPerYr['budget'] = votesPerYr['budget'].str.replace('$', '').str.replace(',','')
#votesPerYr['budget'] = pd.to_numeric(votesPerYr['budget'])

#votesPerYr['budget'] = votesPerYr['budget'].str.replace('AUD', '').str.replace(',','')
#votesPerYr['budget'] = pd.to_numeric(votesPerYr['budget'])

#votesPerYr['budget'] = votesPerYr['budget'].str.replace('EUR', '').str.replace(',','')
#votesPerYr['budget'] = pd.to_numeric(votesPerYr['budget'])

#votesPerYr['budget'] = votesPerYr['budget'].str.replace('CAD', '').str.replace(',','')
#votesPerYr['budget'] = pd.to_numeric(votesPerYr['budget'])

#won't work

votesPerYr.dtypes

#can't get budget to change to int


# In[ ]:


###################################################################################
#Descriptive Statistics
###################################################################################

##VISUALIZATION


# In[8]:


#Visualize data with a heatmap
#code help from https://towardsdatascience.com/better-heatmaps-and-correlation-matrix-plots-in-python-41445d0f2bec

data =votesPerYr

corr = data.corr()
ax = sns.heatmap(
    corr, 
    vmin=-1, vmax=1, center=0,
    cmap=sns.diverging_palette(220, 90, n=6),
    square=True
)
ax.set_xticklabels(
    ax.get_xticklabels(),
    rotation=45,
    horizontalalignment='right'
);

#works!


# In[9]:


#Removed multicollinearity variables
#Visualize data with a heatmap
#code help from https://towardsdatascience.com/better-heatmaps-and-correlation-matrix-plots-in-python-41445d0f2bec

data =votesPerYr
columns = ['year','duration','budget', 'worlwide_gross_income','weighted_average_vote']
corr = data[columns].corr()
#corr = data.corr()
ax = sns.heatmap(
    corr, 
    vmin=-1, vmax=1, center=0,
    cmap=sns.diverging_palette(220, 90, n=6),
    square=True
)
ax.set_xticklabels(
    ax.get_xticklabels(),
    rotation=45,
    horizontalalignment='right'
);

#works!

#Make a scatter plot with square markers, set column names as labels
#code help from https://towardsdatascience.com/better-heatmaps-and-correlation-matrix-plots-in-python-41445d0f2bec


def heatmap(x, y, size):
    fig, ax = plt.subplots()
    
    # Mapping from column names to integer coordinates
    x_labels = [v for v in sorted(x.unique())]
    y_labels = [v for v in sorted(y.unique())]
    x_to_num = {p[1]:p[0] for p in enumerate(x_labels)} 
    y_to_num = {p[1]:p[0] for p in enumerate(y_labels)} 
    
    size_scale = 500
    ax.scatter(
        x=x.map(x_to_num), # Use mapping for x
        y=y.map(y_to_num), # Use mapping for y
        s=size * size_scale, # Vector of square sizes, proportional to size parameter
        marker='s' # Use square as scatterplot marker
    )
    
    # Show column labels on the axes
    ax.set_xticks([x_to_num[v] for v in x_labels])
    ax.set_xticklabels(x_labels, rotation=45, horizontalalignment='right')
    ax.set_yticks([y_to_num[v] for v in y_labels])
    ax.set_yticklabels(y_labels)
    
    ax.grid(False, 'major')
    ax.grid(True, 'minor')
    ax.set_xticks([t + 0.5 for t in ax.get_xticks()], minor=True)
    ax.set_yticks([t + 0.5 for t in ax.get_yticks()], minor=True)
    
    ax.set_xlim([-0.5, max([v for v in x_to_num.values()]) + 0.5]) 
    ax.set_ylim([-0.5, max([v for v in y_to_num.values()]) + 0.5])
    
data = votesPerYr
columns = ['year','duration','budget', 'worlwide_gross_income','weighted_average_vote']
corr = data[columns].corr()
corr = pd.melt(corr.reset_index(), id_vars='index') # Unpivot the dataframe, so we can get pair of arrays for x and y
corr.columns = ['x', 'y', 'value']
heatmap(
    x=corr['x'],
    y=corr['y'],
    size=corr['value'].abs()
)

votesPerYr.describe()

#average vote compared to year

YrVote=pd.DataFrame(votesPerYr.groupby(by=['year','weighted_average_vote','original_title', 'worlwide_gross_income', 'genre']).mean())
YrVote = YrVote.sort_values(by=['year','weighted_average_vote'], ascending=False) #sort top voted movies
YrVote=YrVote.head(1085) #Grab only movies for the last 10 years
YrVote.head(12)
#len(YrVote) #1085

YrVote.describe()


# In[13]:


#x_values=['duration'] #visualization
#y_values=['weighted_average_vote']
#plt.scatter(x_values,y_values, s=10)
#plt.show
#doesn't show anything, missing parameters?

#average vote compared to gross income

voteGross=pd.DataFrame(votesPerYr.groupby(by=['year','weighted_average_vote','original_title', 'worlwide_gross_income']).mean())
voteGross = voteGross.sort_values(by=['weighted_average_vote','year'], ascending=False) #sort top voted movies per year
voteGross.head(10)


# In[14]:


#vote by gender by genre

genGen=pd.DataFrame(votesPerYr.groupby(by=['year','original_title','genre', 'females_allages_avg_vote','males_allages_avg_vote']).mean())
genGen = genGen.sort_values(by=['genre'], ascending=False) #sort top voted movies per genre
genGen.head()
#find max vote by gender per genre
#How to better group this to find answers?


# In[15]:


#budget compared to duration

budDur=pd.DataFrame(votesPerYr.groupby(by=['original_title','budget', 'duration']).mean())
#budDur.max('duration') #doesn't work
#add new column for budget per minute
budDur.head()


# In[16]:


#budget compared to revenue

budRev=pd.DataFrame(votesPerYr.groupby(by=['original_title','budget', 'worlwide_gross_income']).mean())
budRev.head(10)
#add new column for budget:income ratio


# In[17]:


#group by year #sucessful!
dirBugYr=pd.DataFrame(votesPerYr.groupby(by=['year','original_title','budget','duration', 'weighted_average_vote']).mean())
dirBugYr.head(10)


# In[18]:


dirBugYr = dirBugYr.sort_values(by=['year','budget'], ascending=False) #sort top voted movies per year
dirBugYr.head(12)
#does not correctly sort because items are objects, not numbers


# In[12]:


#######################
#Sentiment Analysis
#######################

#Look at the file

#This file is not going to help with the business questions, as the reviews are not labeled by title. 
#We will have to use votes to answer the questions about the reviews, in absence of being able to 
#properly import data from Twitter or Facebook. This section is to practice sentiment analysis, but will not 
#contribute to the final report in a meaningful way.
#Code from course code and online research

movie.head() #check structure

movie.isnull().any() #no null
movie['sentiment'].count() #positive or negative 

movie.groupby('sentiment').count() #split exactly evenly positive/negative- is this accurate? Seems unlikely... Dataset only for test/train?

movie.shape
movie.info()
nltk.download('stopwords') #stopwords for analysis

tkn = ToktokTokenizer() #much research to make this work, crediting several online sources for code ideas
stopwords = nltk.corpus.stopwords.words('english')

#define function to remove characters

def removeChar(text):
    soup = BeautifulSoup(text,'html.parser')
    text = soup.get_text()
    text = re.sub('\[[^]]*\]','',text)
    return text

movie['review'] = movie['review'].apply(removeChar)

# stem text to pull off endings that'll recategortize similar words

#define function to stem

def stemmer(text):
    
    ps = nltk.porter.PorterStemmer()
    text = ' '.join([ps.stem(word) for word in text.split()])
    return text

# apply function on review column to standardize words

movie['review'] = movie['review'].apply(stemmer)

movie.head()

from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize

# English stopwords

stopWrd = set(stopwords.words('english'))
print(stopWrd) #check words are in English

# Remove stopwords

#define function remove stopwords

def removeStopwords(text, is_lower_case = False): #help with this code snippet from Kaggle.com
    tokenizers = tkn
    tokens = tokenizers.tokenize(text)
    tokens = [token.strip() for token in tokens]
    if is_lower_case:
        newToken = [token for token in tokens if token not in stopWrd]
    else:
        newToken = [token for token in tokens if token.lower() not in stopWrd]
    newText = ' '.join(newToken)
    return newText

movie['review'] = movie['review'].apply(removeStopwords)
movie.head()

''' 
#From provided Course Code...

This main topic search function for Twitter using the python tweepy package
      Tries to get up to 1000 results from the Twitter REST/Search API search function
        using the tweepy Cursor to repeat the twitter search api requests
      The query string may be a keyword or hashtag, or a set of them connected by or
        example:  query = "#CuseLAX OR CNYlacrosse"
        some queries require quotes on the command line
    Returns a list of json formatted tweets


import tweepy
import json
import sys
from twitter_login_fn import oauth_login
from twitter_login_fn import appauth_login
from DB_fn import save_to_DB



  Uses the tweepy Cursor to wrap a twitter api search for the query string
    Returns json formatted results


def simple_search(api, query, max_results=20):
  # the first search initializes a cursor, stored in the metadata results,
  #   that allows next searches to return additional tweets
  search_results = [status for status in tweepy.Cursor(api.search, q=query).items(max_results)]
  
  # for each tweet, get the json representation
  tweets = [tweet._json for tweet in search_results]
  
  return tweets

# use a main so can get command line arguments
if __name__ == '__main__':
    # Make a list of command line arguments, omitting the [0] element
    # which is the script itself.
    args = sys.argv[1:]
    if not args or len(args) < 4:
        print('usage: python twitter_simple_search.py <query> <num tweets> <DB name> <collection name>')
        sys.exit(1)
    query = args[0]
    num_tweets = int(args[1])
    DBname = args[2]
    DBcollection = args[3]

    # api = oauth_login()
    if needed switch to using the appauth login to avoid rate limiting 
    api = appauth_login()
    print ("Twitter Authorization: ", api)
    
    # access Twitter search
    result_tweets = simple_search(api, query, max_results=num_tweets)
    print ('Number of result tweets: ', len(result_tweets))

    # save the results in a database collection
    #   change names to lowercase because they are not case sensitive
    #   and remove special characters like hashtags and spaces (other special characters may also be forbidden)
    DBname = DBname.lower()
    DBname = DBname.replace('#', '')
    DBname = DBname.replace(' ', '')
    DBcollection = DBcollection.lower()
    DBcollection = DBcollection.replace('#', '')
    DBcollection = DBcollection.replace(' ', '')
    
    # use the save and load functions in this program
    save_to_DB(DBname, DBcollection, result_tweets)

    # Done!
'''

'''
#From provided Course Code...

Provides function that connects to twitter
    Usage is shown in main test program


import tweepy

# put the authorization codes here from your twitter developer application
CONSUMER_KEY = 'p0YmCCxdS5PiJXuoZVQmInRUr'
CONSUMER_SECRET = 'CaWM9AuRIS1Ywi7pHpXkDs3KlD7yNUsxx3nJ8w1tpqOche2g2u'
OAUTH_TOKEN = 'AAAAAAAAAAAAAAAAAAAAAKhuTgEAAAAAPt7EDDF7%2FCpCbc2PFfXbq8R0xwM%3DvDDATRF8UiJ3xtu5unRsgp6rrNQ0EJicuMdUeORr5KvrSiiAE4'
OAUTH_SECRET = 'Your Auth Secret'
          

# login to Twitter with ordinary rate limiting
def oauth_login():
  # get the authorization from Twitter and save in the tweepy package
  auth = tweepy.OAuthHandler(CONSUMER_KEY,CONSUMER_SECRET)
  auth.set_access_token(OAUTH_TOKEN,OAUTH_SECRET)
  tweepy_api = tweepy.API(auth)

  # if a null api is returned, give error message
  if (not tweepy_api):
      print ("Problem Connecting to API with OAuth")

  # return the twitter api object that allows access for the tweepy api functions
  return tweepy_api

# login to Twitter with extended rate limiting
#  must be used with the tweepy Cursor to wrap the search and enact the waits
def appauth_login():
  # get the authorization from Twitter and save in the tweepy package
  auth = tweepy.AppAuthHandler(CONSUMER_KEY,CONSUMER_SECRET)
  # apparently no need to set the other access tokens
  tweepy_api = tweepy.API(auth, wait_on_rate_limit=True, wait_on_rate_limit_notify=True)

  # if a null api is returned, give error message
  if (not tweepy_api):
      print ("Problem Connecting to API with AppAuth")

  # return the twitter api object that allows access for the tweepy api functions
  return tweepy_api
    
# Test program to show how to connect
if __name__ == '__main__':
  tweepy_api = oauth_login()
  print ("Twitter OAuthorization: ", tweepy_api)
  tweepy_api = appauth_login()
  print ("Twitter AppAuthorization: ", tweepy_api)
'''


# In[ ]:




