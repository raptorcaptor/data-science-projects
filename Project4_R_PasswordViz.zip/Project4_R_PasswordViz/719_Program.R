########################################################################
# 
# Author: Chileen Duncan
# Purpose: Final Poster
#
# Dataset Information: https://www.kaggle.com/prasertk/top-200-common-passwords-in-2021/data
#
########################################################################

########################################################################
# Load Libraries
########################################################################

library(ggplot2)
library(RColorBrewer)
library(wordcloud) 
library(wordcloud2)
library(alluvial)

########################################################################
# Load Dataset
########################################################################

my.dir <- "/Users/chileenmacmini/Desktop/*DESKTOP/*IST719/DataSets/"
myData <- read.csv(file=paste0(my.dir, "top_200_password_2020_by_country.csv")
                   , header = TRUE
                   , stringsAsFactors = FALSE)

########################################################################
# Explore Dataset- Preliminary
########################################################################

#View(myData)
summary(myData)
dim(myData)
colnames(myData)
str(myData)
head(myData)
tail(myData)
max(myData$Time_to_crack_in_seconds) # 3214080000
3214080000/60/60/24/365 # 101.9 years

min(myData$Time_to_crack_in_seconds) #0

################################################################################################################################################
# Question #1
################################################################################################################################################

#1 What are the top twenty most used passwords in the world(by number of users)?

################################################################################################################################################
# Question #2
################################################################################################################################################

#2 Are poor password practices a global issue?

################################################################################################################################################
# Question #3
################################################################################################################################################

#3 What percentage of the most common passwords are "cracked" in <1 second?

################################################################################################################################################

########################################################################
# Clean
########################################################################

# Remove NAs

tmp <- myData
is.na(tmp) # looks for NAs
tmp <- na.omit(tmp)
any(is.na(tmp))
myData1 <- tmp
#View(myData1)
summary(myData1)
str(myData1)

# Removing NAs also removed most of the passwords with long crack times, as they did not have a global ranking
# This is acceptable to analyze the most common passwords, and will decrease outliers

########################################################################
# Single Dimension Plot #1- Boxplot of Time to crack in seconds
########################################################################

num.colors <- 5
FUN <- colorRampPalette(c("red", "green", "blue"))
my.cols <- FUN(num.colors)
boxplot(myData$Time_to_crack_in_seconds, col = my.cols
        , ylim = c(0,10000)
        , ylab = "Time to crack in seconds"
        , xlab = "Global usage ranking"
        , main = "Most Popular Passwords by Time to 'Crack'"
)

########################################################################
# Single Dimension Plot #2- Histogram of Time to crack in seconds
########################################################################

hist(myData$Time_to_crack_in_seconds, col = my.cols
     , main = "Most Popular Passwords by Time to 'Crack'"
)

########################################################################
# Multi-Dimensional Plot #1- Scatter Time to Crack and Global Rank <= 10800 seconds
########################################################################

my.alpha <- 100
col.vec <- rep(rgb(32,170,74, maxColorValue = 255, alpha = my.alpha) # repeat color value for base color bright red
               ,nrow(myData1))

col.vec[myData1$Time_to_crack_in_seconds > 1] <- rgb(17,90,46
                                                     , maxColorValue = 255, alpha = my.alpha) # time to crack >1 second is med red

col.vec[myData1$Time_to_crack_in_seconds > 1500] <- rgb(17,56,30
                                                        , maxColorValue = 255, alpha = my.alpha) # time to crack > 25 minutes is dark red

plot(myData1$Time_to_crack_in_seconds, myData1$Global_rank, col = col.vec #Range of password cracking time
     , xlim = c(0,11000)
     , xlab = "Time to crack in seconds"
     , ylab = "Global usage ranking"
     , main = "Distribution of Popular Password Use by Time to Crack <= 10800 seconds (180 minutes)"
) #plots all colors

########################################################################
# Multi-Dimensional Plot #2- Scatter Time to Crack and Global Rank <= 10 seconds
########################################################################

plot(myData1$Time_to_crack_in_seconds, myData1$Global_rank, col = col.vec #Most popular passwords
     , xlim = c(0,10)
     , xlab = "Time to crack in seconds"
     , ylab = "Global usage ranking"
     , main = "Distribution of Popular Password Use by Time to Crack <= 10 seconds"
) #plots all colors

########################################################################
# Multi-Dimensional Plot #3- Password WordCloud- Global
########################################################################

def.par <- par(no.readonly = TRUE) # sets par default

dat.9 <- aggregate(myData1$User_count^(1/5), list(myData1$Password), sum)
colnames(dat.9) <- c("Password","UserCount")
dat.9

wordcloud2(dat.9, size = 0.7, backgroundColor = "#C7DDC7", shape = "circle", color = rep_len(c("#11381E", "#11381E", "#115A2E", "#20AA4A"), nrow(dat.9)))

par(def.par) # returns par to default

################################################################################################################################################
#
# Question #1
#
################################################################################################################################################

#1 What are the top twenty most used passwords in the world(by number of users)?

################################################################################################################################################

########################################################################
# Global- Barchart
########################################################################

myData2 <- data.frame(myData1$country, myData1$Password, myData1$User_count) # all countries

colnames(myData2) <- c("Country", "Password", "UserCount")

dat.11 <- aggregate(myData2$UserCount, list(myData2$Password), sum) # Global
colnames(dat.11) <- c("Password","UserCount")
dat.11 # correct, global, not in order

# grab top 20 top used passwords
dat.11 <- dat.11[order(-dat.11$UserCount),][1:20,] # top 20 global passwords

ggplot(dat.11) + aes(x=reorder(Password, UserCount), y = UserCount, fill = UserCount) + 
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

################################################################################################################################################
# Question #2
################################################################################################################################################
#
# 2 Are poor password practices a global issue?
#
################################################################################################################################################

########################################################################
# US- Barchart
########################################################################

# grab country = US
myData2.C <- myData2$Country

mydf2 <- data.frame(myData2.C, myData2$Password, myData2$UserCount) # all countries with password and user count
colnames(mydf2) <- c("Country", "Password", "UserCount")

country.us <- mydf2[mydf2$Country == "United States",] # pick out US
dat.6 <- aggregate(country.us$UserCount, list(country.us$Password), sum) # US Only
colnames(dat.6) <- c("Password","UserCount")
dat.6 # correct, US only, not in order

# grab top 20 top used passwords
mydf3 <- dat.6[order(-dat.6$UserCount),][1:20,] # top 20 US passwords

ggplot(mydf3) + aes(x=reorder(Password, UserCount), y = UserCount, fill = UserCount) + 
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

########################################################################
# US- Wordcloud
########################################################################

index <- which(dat.6$UserCount > 10) # Only use words that show up more than 10 times. This helps if words don't fit on page
par(mar = c(0,0,0,0)) # set the margins very small. This helps if words don't fit on page
my.counts <- (dat.6$UserCount[index])^(1/2) # create new variable to transform

# Top passwords for us by user count
dat.8 <- aggregate(mydf2$UserCount^(1/5), list(mydf2$Password), sum)
colnames(dat.8) <- c("Password","UserCount")
dat.8

wordcloud2(dat.8, size = 0.7, shape = "circle", backgroundColor = "#C7DDC7", color = rep_len(c("red", "black", "blue"), nrow(dat.8))) # make wordcloud

########################################################################
# Belgium- Barchart
########################################################################

# grab country = Belgium
myData2.C <- myData2$Country

mydf2 <- data.frame(myData2.C, myData2$Password, myData2$UserCount) # all countries
colnames(mydf2) <- c("Country", "Password", "UserCount")

country.us <- mydf2[mydf2$Country == "Belgium",] # pick out Belgium
dat.6 <- aggregate(country.us$UserCount, list(country.us$Password), sum) # US Only
colnames(dat.6) <- c("Password","UserCount")
dat.6 # correct, Belgium only, not in order

# grab top 20 top used passwords
mydf3 <- dat.6[order(-dat.6$UserCount),][1:20,] # top 20 Belgium passwords

# Barchart for Belgium
ggplot(mydf3) + aes(x=reorder(Password, UserCount), y = UserCount, fill = UserCount) + 
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

########################################################################
# Belgium- Wordcloud
########################################################################

index <- which(dat.6$UserCount > 10) # Only use words that show up more than 10 times. This helps if words don't fit on page
par(mar = c(0,0,0,0)) # set the margins very small. This helps if words don't fit on page
my.counts <- (dat.6$UserCount[index])^(1/2) # create new variable to transform

# Top passwords for us by user count
dat.8 <- aggregate(mydf2$UserCount^(1/5), list(mydf2$Password), sum)
colnames(dat.8) <- c("Password","UserCount")
dat.8

wordcloud2(dat.8, size = 0.7, shape = "circle", backgroundColor = "#C7DDC7", color = rep_len(c("black", "yellow", "red"), nrow(dat.8))) # make wordcloud

########################################################################
# Brazil- Barchart
########################################################################

# grab country = Brazil
myData2.C <- myData2$Country

mydf2 <- data.frame(myData2.C, myData2$Password, myData2$UserCount) # all countries
colnames(mydf2) <- c("Country", "Password", "UserCount")

country.us <- mydf2[mydf2$Country == "Brazil",] # pick out Brazil
dat.6 <- aggregate(country.us$UserCount, list(country.us$Password), sum) # US Only
colnames(dat.6) <- c("Password","UserCount")
dat.6 # correct, Brazil only, not in order

# grab top 20 top used passwords
mydf3 <- dat.6[order(-dat.6$UserCount),][1:20,] # top 20 US passwords

# Barchart for Brazil
ggplot(mydf3) + aes(x=reorder(Password, UserCount), y = UserCount, fill = UserCount) + 
  geom_bar(stat = "identity") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

def.par <- par(no.readonly = TRUE) # sets par default

########################################################################
# Brazil- Wordcloud
########################################################################

index <- which(dat.6$UserCount > 10) # Only use words that show up more than 10 times. This helps if words don't fit on page
par(mar = c(0,0,0,0)) # set the margins very small. This helps if words don't fit on page
my.counts <- (dat.6$UserCount[index])^(1/2) # create new variable to transform

# wordcloud #2
# Top passwords for us by user count
dat.8 <- aggregate(mydf2$UserCount^(1/5), list(mydf2$Password), sum)
colnames(dat.8) <- c("Password","UserCount")
dat.8

wordcloud2(dat.8, size = 0.7, shape = "circle", backgroundColor = "#C7DDC7", color = rep_len(c("green", "yellow", "blue"), nrow(dat.8))) # make wordcloud

par(def.par) # returns par to default

################################################################################################################################################
# Question #3
################################################################################################################################################
#
#3 What percentage of the most common passwords are "cracked" in <1 second?
#
################################################################################################################################################

########################################################################
# Alluvial Plot
########################################################################

par(mar = c(6, 5, 5, 1), cex.lab = .8) #set margins, 6 on bottom, 0 on top

#############################
# set up alluvial df
#############################

mydf2 <- data.frame(myData2.C, myData2$Password, myData2$UserCount) # all countries with password and user count
colnames(mydf2) <- c("Country", "Password", "UserCount")

# aggregate
df <- aggregate(myData1$Time_to_crack_in_seconds
                , list(myData1$Global_rank, myData1$Password) # continuous, categorical, gave readable names
                , sum) # function to sum

# order
alluv.df1 <- df[order(df$Group.1, df$x),][1:40,]# change the order of the df, sort on df$type, followed by df$x, keep all columns
# dat.11 <- dat.11[order(-dat.11$UserCount),][1:20,] # top 20 global passwords

colnames(alluv.df1) <- c("Global Rank", "Password", "Time To Crack") # add useful column names

#############################
# set up alluvial plot
#############################

my.cols <- rep("red", nrow(alluv.df1)) # rep = repeat. All red for baseline vector

# alluvial(alluv.df1[, 1:2], freq = alluv.df1$`Time To Crack`
#          , col = my.cols) # add in color variables just set

alluvial(alluv.df1[, 1:3], freq = alluv.df1$`Time To Crack` 
         , col = ifelse(alluv.df1$`Global Rank` == "red", "red", "green")
         , border = 9 # border color
         , alpha = .8 # transparency
         , gap.width = 1.2) # gap between label boxes


########################################################################
#
# END OF CODE
#
########################################################################




